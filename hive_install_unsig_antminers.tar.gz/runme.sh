
#rm /etc/default/dropbear 2>/dev/null
#/etc/init.d/dropbear start
sh start.sh
